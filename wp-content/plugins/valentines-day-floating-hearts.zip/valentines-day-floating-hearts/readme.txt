=== Plugin Name ===
Contributors: Digitally Cultured
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=CSAFBFPC4FSL8/
Tags: Valentine's day, floating, hearts, festive
Requires at least: 3.0.1
Tested up to: 4.9.6
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Simple plugin to give a touch of Valentine's Day spirit!

== Description ==
When the plugin is activated, the front end of your site will have floating hearts to help spread love!
== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Turn on the floating hearts in the Appearance | Floating Hearts menu page
4. Spread the love!

== Screenshots ==

1. Spread the love on Valentine's Day!

== Changelog ==

= 2.0 =
* Add: new configuration page, found in the Appearance menu, called Floating Hearts
* Add: ability to turn on/off the display of the hearts on the front end of your site
* Edit: force the heart to use color scheme by changing CSS class & adding !important to CSS styles

= 1.0 =
* Plugin created and added to repository